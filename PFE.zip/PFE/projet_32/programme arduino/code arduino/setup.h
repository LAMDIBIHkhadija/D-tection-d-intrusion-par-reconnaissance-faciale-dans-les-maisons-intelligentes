

#ifndef LIVEOV7670_SETUP_H
#define LIVEOV7670_SETUP_H


#define EXAMPLE 1



void initializeScreenAndCamera();
void processFrame();



#endif //LIVEOV7670_SETUP_H

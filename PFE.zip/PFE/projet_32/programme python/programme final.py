import os
import datetime
import time
import cv2
#fonction pour comparer les images ---------------------------------------------
def comparer_images(img1, img2):
 
        if img1.shape != img2.shape:
            return 0
        
         # Calculer la différence absolue entre les images
        diff = cv2.absdiff(img1, img2)

        # Convertir la différence en niveaux de gris
        gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)

       # Appliquer un flou gaussien pour réduire le bruit
        blur = cv2.GaussianBlur(gray, (5, 5), 0)

       # Seuiller l'image pour obtenir un masque binaire
        _, thresh = cv2.threshold(blur, 20, 255, cv2.THRESH_BINARY)

    # Trouver les contours de l'image seuillée
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Vérifier si les contours trouvés sont identiques
        if len(contours) == 0:
         return 1
        else:
         return 0
#la fonction de la reconnaissence faciale -------------------------------------------------
def reconnaissence(img):
    import numpy as np
    import face_recognition
    import smtplib
    from email.mime.text import MIMEText
    from datetime import datetime
    # Obtenir l'heure actuelle
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    # Configurer les paramètres de messagerie électronique.
    sender = 'tpython45@gmail.com'
    recipient = 'aymanmohcin123@gmail.com'
    password = 'mntloyhcikpqdvpc'

    smtp_server = 'smtp.gmail.com'

    path = 'image'
    images = []
    classNames = []
    personsList = os.listdir(path)

    for cl in personsList:
        curPersonn = cv2.imread(f'{path}/{cl}')
        images.append(curPersonn)
        classNames.append(os.path.splitext(cl)[0])
        print(classNames)

    def findEncodeings(image):
        encodeList = []
        for img in images:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            encode = face_recognition.face_encodings(img)[0]
            encodeList.append(encode)
        return encodeList

    encodeListKnown = findEncodeings(images)
    print('Encoding Complete.')

    imgS = cv2.resize(img, (0,0), None, 0.25, 0.25)
    imgS = cv2.cvtColor(imgS, cv2.COLOR_BGR2RGB)

    faceCurentFrame = face_recognition.face_locations(imgS)
    encodeCurentFrame = face_recognition.face_encodings(imgS, faceCurentFrame)

    # Créer une liste de noms reconnus.
    recognizedNames = []
    for encodeface, faceLoc in zip(encodeCurentFrame, faceCurentFrame):
        matches = face_recognition.compare_faces(encodeListKnown, encodeface)
        faceDis = face_recognition.face_distance(encodeListKnown, encodeface)
        matchIndex = np.argmin(faceDis)

        if matches[matchIndex]:
            name = classNames[matchIndex].upper()
            print(name)
            recognizedNames.append(name)
        else:
            print('personne inconnue')
            recognizedNames.append('personne inconnue')
        



    # Ajouter l'heure d'arrivée avec les noms reconnus
    if(len(recognizedNames)==0):
        recognizedNames.append('un objet')
        print("un objet")
    recognizedNamesWithTime = [f'{name} à {current_time}' for name in recognizedNames]

    # Envoyer l'alerte via l'email avec les noms reconnus et l'heure

    msg = MIMEText(f'{", ".join(recognizedNamesWithTime)} devant la porte')
    msg['Subject'] = 'Face recognition alert'
    msg['From'] = sender
    msg['To'] = recipient

    with smtplib.SMTP(smtp_server, 587) as smtp:
        smtp.starttls()
        smtp.login(sender, password)
        smtp.send_message(msg)

#-------------------------------------------------------------------
photo_dir = "C:\\Users\\hp\\Documents\\Arduino\\Outils\\ArduImageCapture\\image"
nbr=0
# Boucle infinie
while True:
    
    # Récupérer la date de la dernière exécution du programme
    try:
        with open("last_run.txt", "r") as f:
            last_run = datetime.datetime.strptime(f.read().strip(), "%Y-%m-%d %H:%M:%S.%f")
    except FileNotFoundError:
        last_run = datetime.datetime.now()

    # Parcourir le dossier des photos et trouver les nouvelles
    new_photos = []
    for filename in os.listdir(photo_dir):
        filepath = os.path.join(photo_dir, filename)
        if os.path.isfile(filepath):
            filetime = datetime.datetime.fromtimestamp(os.path.getmtime(filepath))
            if filetime > last_run:
                new_photos.append(filepath)

     # Ajouter les nouvelles photos à votre programme
    if len(new_photos)>0:
        photo=new_photos[-1]
    else:
        print("j'ai pas trouvé une nouvelle phto ")
        time.sleep(20)
        continue
    # Lire l'image avec OpenCV
    image = cv2.imread(photo)
    if nbr==0:
        photo2=new_photos[-2]
        img = cv2.imread(photo2)
        nbr=nbr+1
    i=comparer_images(image, img)
    if i==0:
     
        print(f"J'ai trouvé une nouvelle photo : {photo}")
    
        cv2.imshow("Nouvelle photo", image)
        # Attendre  seconde pour afficher l'image avant de passer à la suivante
        cv2.waitKey(5000)
        # Fermer toutes les fenêtres OpenCV
        cv2.destroyAllWindows()
        reconnaissence(image)
    else :
        print("j'ai pas trouvé une nouvelle phto ")

    # Enregistrer la date de cette exécution du programme
    with open("last_run.txt", "w") as f:
        f.write(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"))
    #supprimer tous les éléments
    new_photos.clear()
    img=image
    # Pause de 20 secondes avant la prochaine exécution du programme
    time.sleep(20)
